.. _APE: 				http://ape.mpl.ird.fr/
.. _biom:				http://biom-format.org
.. _GPL:				http://www.gnu.org/licenses/gpl-2.0.html
.. _Greengenes:				http://greengenes.lbl.gov
.. _KEGG:				http://www.genome.jp/kegg/
.. _KO:					http://www.genome.jp/kegg/ko.html
.. _PICRUST:				http://picrust.github.com
.. _PICRUSt software:			https://github.com/picrust/picrust/tags
.. _PICRUSt development software: 	https://github.com/picrust/picrust
.. _PICRUST metagenome tutorial files:	https://www.dropbox.com/s/yndl609h5m069y6/metagenome_prediction_tutorial_files.zip
.. _PICRUSt GG reference data:		https://s3.amazonaws.com/picrust-public-data/img_gg_otus_18may2012.tgz
.. _PICRUST starting files: 		https://dl.dropbox.com/s/yvymi52uiwgltqt/picrust_starting_files.zip?dl=1
.. _PICRUST precalculated files: 	https://dl.dropbox.com/s/f8sy84kxi2havww/picrust_precalculated_files.tgz?dl=1
.. _PICRUST temporary files:		https://dl.dropbox.com/sh/7x2e2zh65yuf45u/VbWVrx392K/tutorial_files/picrust_temporary_files.zip?dl=1
.. _PICRUST users list: 		https://groups.google.com/group/picrust-users/subscribe?note=1&hl=en&noredirect=true&pli=1
.. _PyCogent:				http://www.pycogent.org/
.. _QIIME:				http://www.qiime.org
.. _R: 					http://www.r-project.org/
.. _numpy: 					http://www.numpy.org/
.. _python: 					http://www.python.org/
.. |dummy|				replace:: :py:mod:`dummy`
