.. _index_examples:

==================================
Pre-picrust usage examples
==================================

.. toctree::
   :maxdepth: 1
   :glob:

   ./*