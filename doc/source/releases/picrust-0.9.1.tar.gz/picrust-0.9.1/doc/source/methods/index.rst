.. _index_methods:

==================================
PICRUSt Methods
==================================

.. toctree::
   :maxdepth: 1
   :glob:

   ./*
